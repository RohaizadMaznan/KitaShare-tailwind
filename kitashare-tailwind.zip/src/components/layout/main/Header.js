import React, { useState, useEffect, useRef } from "react";
import fire from "../../../auth/fbAuth";
import { Link, useHistory } from "react-router-dom";
import StudentAvatar from "../documentation/Avatar";
import AdminAvatar from "../admin/Avatar";

function Header() {
  const [top, setTop] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const searchInputRef = useRef(null);
  const history = useHistory();

  fire.auth().onAuthStateChanged((user) => {
    if (user) {
      setLoggedIn(true);
    } else {
      setLoggedIn(false);
    }
  });

  // detect whether user has scrolled the page down by 10px
  useEffect(() => {
    const scrollHandler = () => {
      window.pageYOffset > 10 ? setTop(false) : setTop(true);
    };
    window.addEventListener("scroll", scrollHandler);
    return () => window.removeEventListener("scroll", scrollHandler);
  }, [top]);

  const search = (e) => {
    e.preventDefault();
    const doc = searchInputRef.current.value;

    if (!doc) return;

    history.push(`/search?doc=${doc}`);
    // router.push(`/search?doc=${doc}`);
  };

  let user = fire.auth().currentUser;

  return (
    <header
      className={`fixed w-full z-30 md:bg-opacity-90 transition duration-300 ease-in-out ${!top &&
        "bg-white blur shadow-lg"}`}
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-6">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Site branding */}
          <div className="flex-shrink-0 mr-4">
            {/* Logo */}
            <Link to="/" className="block" aria-label="Cruip">
              <svg
                className="w-8 h-8"
                viewBox="0 0 32 32"
                xmlns="http://www.w3.org/2000/svg"
              >
                <defs>
                  <radialGradient
                    cx="21.152%"
                    cy="86.063%"
                    fx="21.152%"
                    fy="86.063%"
                    r="79.941%"
                    id="header-logo"
                  >
                    <stop stopColor="#4FD1C5" offset="0%" />
                    <stop stopColor="#81E6D9" offset="25.871%" />
                    <stop stopColor="#338CF5" offset="100%" />
                  </radialGradient>
                </defs>
                <rect
                  width="32"
                  height="32"
                  rx="16"
                  fill="url(#header-logo)"
                  fillRule="nonzero"
                />
              </svg>
            </Link>
          </div>

          {/* Site navigation */}
          <nav className="flex flex-grow">
            <ul className="flex flex-grow justify-end flex-wrap items-center">
              <li className="hidden md:block">
                <form autoComplete="off" onSubmit={search}>
                  <div className="relative text-gray-600">
                    <input
                      ref={searchInputRef}
                      type="search"
                      name="search"
                      placeholder="Search"
                      className="bg-gray-100 border h-10 px-5 pr-10 rounded-full text-sm focus:outline-none focus:bg-gray-200"
                    />
                    <button
                      type="submit"
                      className="absolute right-0 top-0 mt-3 mr-4"
                    >
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        className="h-4 w-4"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth="2"
                          d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                        />
                      </svg>
                    </button>
                  </div>
                </form>
              </li>

              {!loggedIn ? (
                <>
                  <li>
                    <Link
                      to="/signin"
                      className="font-medium text-gray-600 hover:text-gray-900 px-5 py-3 flex items-center transition duration-150 ease-in-out"
                    >
                      Sign in
                    </Link>
                  </li>
                  <li>
                    <Link
                      to="/signup"
                      className="btn-sm text-gray-200 bg-gray-900 hover:bg-gray-800 ml-3"
                    >
                      <span>Sign up</span>
                      <svg
                        className="w-3 h-3 fill-current text-gray-400 flex-shrink-0 ml-2 -mr-1"
                        viewBox="0 0 12 12"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          d="M11.707 5.293L7 .586 5.586 2l3 3H0v2h8.586l-3 3L7 11.414l4.707-4.707a1 1 0 000-1.414z"
                          fillRule="nonzero"
                        />
                      </svg>
                    </Link>
                  </li>
                </>
              ) : (
                <>
                  {user.email === "admin@kitashare.com" ? (
                    <li>
                      <AdminAvatar />
                    </li>
                  ) : (
                    <li>
                      <StudentAvatar />
                    </li>
                  )}
                </>
              )}
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;
